create view importes as
select `bd_neptuno2`.`detalles`.`pedido_id`         AS `pedido_id`,
       `bd_neptuno2`.`detalles`.`producto_id`       AS `producto_id`,
       `bd_neptuno2`.`detalles`.`precio_unidad`     AS `precio_unidad`,
       `bd_neptuno2`.`detalles`.`cantidad`          AS `cantidad`,
       `bd_neptuno2`.`detalles`.`descuento`         AS `descuento`,
       ((`bd_neptuno2`.`detalles`.`precio_unidad` * `bd_neptuno2`.`detalles`.`cantidad`) *
        (1 - `bd_neptuno2`.`detalles`.`descuento`)) AS `importe`
from `bd_neptuno2`.`detalles`;

