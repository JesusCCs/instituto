create
    definer = root@localhost function tipo_de_via(direccion varchar(50)) returns varchar(10)
begin
	declare tipoDireccion varchar(10);
	if direccion like '%Avda%' then
		set tipoDireccion="Avda";
    elseif direccion like '%Avenida%' then
		set tipoDireccion="Avenida";
	elseif direccion like '%Calle%' then
		set tipoDireccion="Calle";
	elseif direccion like '%Camino%' then
		set tipoDireccion="Camino";
	elseif direccion like '%Plaza%' then
		set tipoDireccion="Plaza";
	else 
		set tipoDireccion="NA";
    end if;

	return tipoDireccion;
end;

