create view totales_mensuales as
select year(`totales`.`fecha_pedido`)                                                       AS `año`,
       month(`totales`.`fecha_pedido`)                                                      AS `mes`,
       (`totales`.`fecha_pedido` + interval (1 - dayofmonth(`totales`.`fecha_pedido`)) day) AS `fecha`,
       round(sum(`totales`.`cargo`), 0)                                                     AS `cargo`,
       round(sum(`totales`.`importe`), 0)                                                   AS `importe`,
       round(sum(`totales`.`total`), 0)                                                     AS `total`,
       count(`totales`.`id`)                                                                AS `num_pedidos`
from `bd_neptuno2`.`totales`
group by year(`totales`.`fecha_pedido`), month(`totales`.`fecha_pedido`);

