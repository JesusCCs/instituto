create view v_empleados1 as
select `bd_neptuno2`.`empleados`.`id`                 AS `id`,
       `bd_neptuno2`.`empleados`.`apellidos`          AS `apellidos`,
       `bd_neptuno2`.`empleados`.`nombre`             AS `nombre`,
       `bd_neptuno2`.`empleados`.`cargo`              AS `cargo`,
       `bd_neptuno2`.`empleados`.`tratamiento`        AS `tratamiento`,
       `bd_neptuno2`.`empleados`.`fecha_nacimiento`   AS `fecha_nacimiento`,
       `bd_neptuno2`.`empleados`.`fecha_contratacion` AS `fecha_contratacion`,
       `bd_neptuno2`.`empleados`.`direccion`          AS `direccion`,
       `bd_neptuno2`.`empleados`.`ciudad`             AS `ciudad`,
       `bd_neptuno2`.`empleados`.`region`             AS `region`,
       `bd_neptuno2`.`empleados`.`cp`                 AS `cp`,
       `bd_neptuno2`.`empleados`.`pais`               AS `pais`,
       `bd_neptuno2`.`empleados`.`telefono_domicilio` AS `telefono_domicilio`,
       `bd_neptuno2`.`empleados`.`extension`          AS `extension`,
       `bd_neptuno2`.`empleados`.`notas`              AS `notas`,
       `bd_neptuno2`.`empleados`.`jefe_id`            AS `jefe_id`
from `bd_neptuno2`.`empleados`;

