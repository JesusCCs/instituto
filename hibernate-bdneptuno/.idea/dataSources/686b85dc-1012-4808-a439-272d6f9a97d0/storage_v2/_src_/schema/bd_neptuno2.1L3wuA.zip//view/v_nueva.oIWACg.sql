create view v_nueva as
select `bd_neptuno2`.`productos`.`id`                  AS `id`,
       `bd_neptuno2`.`productos`.`producto`            AS `producto`,
       `bd_neptuno2`.`productos`.`proveedor_id`        AS `proveedor_id`,
       `bd_neptuno2`.`productos`.`categoria_id`        AS `categoria_id`,
       `bd_neptuno2`.`productos`.`cantidad_por_unidad` AS `cantidad_por_unidad`
from (`bd_neptuno2`.`productos`
         join `bd_neptuno2`.`categorias`
              on ((`bd_neptuno2`.`productos`.`categoria_id` = `bd_neptuno2`.`categorias`.`id`)));

