create
    definer = root@localhost procedure modifica_horas_mensuales(IN var_incremento_precio_hora decimal(8, 2),
                                                                IN var_incremento_horas_trabajadas decimal(8, 2),
                                                                IN var_year year, IN var_mes int, IN var_id int)
BEGIN

	if var_incremento_precio_hora = null || var_incremento_horas_trabajadas = null || var_year = null || var_mes = null then
		
        select "Parámetros básicos no introducidos";
        
	end if;
    
    if var_id = null then
    
		update horas_mensuales set horas_trabajadas = var_incremento_horas_trabajadas;
UPDATE horas_mensuales 
SET 
    precio_hora = var_precio_hora;
        
    end if;
    
UPDATE horas_mensuales 
SET 
    horas_trabajadas = var_incremento_horas_trabajadas
WHERE
    año = var_year AND mes = var_mes
        AND id_empleado = var_id;
    
UPDATE horas_mensuales 
SET 
    precio_hora = var_precio_hora
WHERE
    año = var_year AND mes = var_mes
        AND id_empleado = var_id;


END;

